# FinancialCalculatorProjectBeta1
Financial Calculator Project .NET Core MVC, JavaScript, Bootstrap, Microsoft.VisualBasic.

CSCB024 Практика по програмиране и интернет технологии
Финансов калкулатор за мобилен телефон

Супервайзор: гл. ас.д-р. Лъчезар Томов
